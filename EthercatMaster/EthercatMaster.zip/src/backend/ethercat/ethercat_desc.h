#pragma once
#include "core/backend/backend_desc.h"

extern const BackendDesc_t ETHERCAT_DRIVER_DESC;