#pragma once

void ethercat_start_thread(EtherCAT_Driver_t* d);
void ethercat_stop_thread(EtherCAT_Driver_t* d);