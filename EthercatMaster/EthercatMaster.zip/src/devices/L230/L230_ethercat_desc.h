
#include "backend/ethercat/ethercat_device_desc.h"
#include "L230_ethercat_pdo.h"

extern const EtherCAT_DeviceDesc_t L230_ECAT_DESC;