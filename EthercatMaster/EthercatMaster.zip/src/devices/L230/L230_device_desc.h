#pragma once
#include "core/device/device.h"

extern const DeviceDesc_t L230_DEVICE_DESC;
