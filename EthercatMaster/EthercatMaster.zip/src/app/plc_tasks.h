#pragma once

int plc_task1_run(void* ctx);