#pragma once
#include "scheduler.h"

void scheduler_start_thread(Scheduler_t* s);
void scheduler_stop_thread(Scheduler_t* s);