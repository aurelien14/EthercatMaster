#pragma once

int os_thread_join(void* thandle, void** value_ptr);
