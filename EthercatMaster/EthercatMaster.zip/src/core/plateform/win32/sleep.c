#include "sleep.h"

void sleep(unsigned long ms) {
	Sleep(ms);
}